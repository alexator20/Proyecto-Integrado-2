import { Component } from '@angular/core';

@Component({
  selector: 'app-baden-powell',
  standalone: true,
  imports: [],
  templateUrl: './baden-powell.component.html',
  styleUrl: './baden-powell.component.css'
})
export class BadenPowellComponent {

}
