import { Component } from '@angular/core';

@Component({
  selector: 'app-manada',
  standalone: true,
  imports: [],
  templateUrl: './manada.component.html',
  styleUrl: './manada.component.css'
})
export class ManadaComponent {

}
