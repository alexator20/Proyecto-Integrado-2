import { Component } from '@angular/core';

@Component({
  selector: 'app-clan',
  standalone: true,
  imports: [],
  templateUrl: './clan.component.html',
  styleUrl: './clan.component.css'
})
export class ClanComponent {

}
