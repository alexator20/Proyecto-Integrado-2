import { Component } from '@angular/core';

@Component({
  selector: 'app-esculta',
  standalone: true,
  imports: [],
  templateUrl: './esculta.component.html',
  styleUrl: './esculta.component.css'
})
export class EscultaComponent {

}
