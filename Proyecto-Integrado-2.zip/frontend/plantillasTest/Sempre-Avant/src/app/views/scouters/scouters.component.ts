import { Component } from '@angular/core';

@Component({
  selector: 'app-scouters',
  standalone: true,
  imports: [],
  templateUrl: './scouters.component.html',
  styleUrl: './scouters.component.css'
})
export class ScoutersComponent {

}
