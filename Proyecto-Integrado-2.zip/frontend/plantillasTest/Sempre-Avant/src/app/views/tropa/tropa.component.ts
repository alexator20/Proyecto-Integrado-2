import { Component } from '@angular/core';

@Component({
  selector: 'app-tropa',
  standalone: true,
  imports: [],
  templateUrl: './tropa.component.html',
  styleUrl: './tropa.component.css'
})
export class TropaComponent {

}
