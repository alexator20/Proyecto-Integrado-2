import { Component } from '@angular/core';

@Component({
  selector: 'app-escolta',
  standalone: true,
  imports: [],
  templateUrl: './escolta.component.html',
  styleUrl: './escolta.component.css'
})
export class EscoltaComponent {

}
