import { Component } from '@angular/core';

@Component({
  selector: 'app-castores',
  standalone: true,
  imports: [],
  templateUrl: './castores.component.html',
  styleUrl: './castores.component.css'
})
export class CastoresComponent {

}
